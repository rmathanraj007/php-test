
$(function () {    
    $('#addTableForm').parsley(); 
    $('#editTableForm').parsley();
    loadItems();
    
    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });    
  });
  
  
   $('#addUserBtn').click(function(){
     $('#addItemModal').modal('show');
 });
 
 
 $("#addTableForm").on('submit',function(e){
    e.preventDefault();  
    if ( $(this).parsley().isValid() ) {
        $.ajax({
            url: "Tables/addTableProcess",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (response)
            {
                if (response == 1)
                {                   
                    $("#addTableForm").trigger("reset");
                    //$("#alert_message").html("<div class='alert alert-success'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Table Added Successfully!!</div>");
                    swal("Table Added Successfully", "All Fields are Inserted", "success");
//                     setTimeout(function () {
//                        $('.alert').fadeOut('slow');
//                    }, 5000);
                    loadTables();
                }
                else if(response == 2){
                    $("#alert_message").html("<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Table Add not Success!!</div>");
                    setTimeout(function () {
                        $('.alert').fadeOut('slow');
                    }, 5000);                   
                }else if(response == 3){
                    $("#alert_message").html("<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Table Name Already Exist!!</div>");
                    setTimeout(function () {
                        $('.alert').fadeOut('slow');
                    }, 5000);                   
                }
                 $('#addTableModal').modal('hide');    
            },
            error: function (response) {
               alert("Error occurd! Please try again");
            }
        });   
    }
 });
  
  function loadItems(){    
    $.ajax(
       {   
           type: "POST",
           url:"Items/loadItems",
           data:{'itemdata':'1'},
            beforeSend: function () {
                $('#myPleaseWait').modal('show');
            }, 
           success: function(response) {
                var data=$.parseJSON(response);
                var table='';
                var i=1;
                var status=""
                table +='<table id="itemsTable" class="table table-bordered table-striped">';
                table +='<thead><tr><th>S.No</th><th>Item Name</th><th>Sort Code</th><th>Amount</th><th>Action</th></tr></thead>';
                table +='<tbody>';
                $.each(data,function(key,value){
                    table +='<tr id="row_'+value.id+'">';
                    table +='<td>'+i+'</td>';                    
                    table +='<td>'+value.item_name+'</td>';
                    table +='<td>'+value.item_name+'</td>';
                    table +='<td>'+value.amount+'</td>';
                    table +='<td><a href="#" onclick="editTable('+value.id+')"><i class="fa fa-eye" aria-hidden="true">  </i> </a> <a href="#" onclick="deleteTable('+value.id+')"><i class="fa fa-times" aria-hidden="true" style="margin-left:10px;color:red"></i></a></td>';
                    table +='</tr>'; 
                    i++;
                });                
                table +='</table>'; 
                $('#PosUsersTableDiv').html(table);
                $("#itemsTable").DataTable();
                $('#myPleaseWait').modal('hide');
           },
           error: function (response) {
               alert("Error occurd! Please try again");
           }
       });     
 }
 
 
 $("#editTableForm").on('submit',function(e){
    e.preventDefault();   
    if ( $(this).parsley().isValid() ) {
        $.ajax({
            url: "Tables/updateTableProcess",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (response)
            {
                if (response == 1)
                {                   
                   // $("#alert_message").html("<div class='alert alert-success'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Table Updated Successfully!!</div>");
                    swal("Table Edited Successfully", "All Fields are Inserted", "success");
//                    setTimeout(function () {
//                        $('.alert').fadeOut('slow');
//                    }, 5000);
                    loadTables();
                }else if(response == 2){
                    $("#alert_message").html("<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>All Fields are Required!!</div>");
                    setTimeout(function () {
                        $('.alert').fadeOut('slow');
                    }, 5000);                   
                }else if(response == 3){
                    $("#alert_message").html("<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Image Size Shoud be 215x215!!</div>");
                    setTimeout(function () {
                        $('.alert').fadeOut('slow');
                    }, 5000);                                     
                }else{
                    $("#alert_message").html("<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Table Update not Success!!</div>");
                    setTimeout(function () {
                        $('.alert').fadeOut('slow');
                    }, 5000);                       
                } 
                 $('#editTableModal').modal('hide');    
            },
            error: function (response) {
               alert("Error occurd! Please try again");
            }
        }); 
    }   
 });
 
 function editTable(id){
    $.ajax({
        url: "Tables/loadTables",
        type: "POST",
        data:{"tableId":id},
        success: function (response)
        {
             var data=$.parseJSON(response);
             $.each(data,function(key,value){
                 $('#updateTableName').val(value.table_name);                
                 $('#hiddenTableId').val(value.id);
                 if(value.status == '1'){
                    $('#UpdateStatus').prop('checked',true);
                 }else{
                    $('#UpdateStatus').prop('checked',false);
                 }                
             });
             $('#editTableModal').modal('show');         
        },
        error: function (response) {
           alert("Error occurd! Please try again");
        }
    });      
 }
 
 function deleteTable(id){
    var x = confirm("Are you sure you want to delete?");
    if (x)
        $.ajax({
            url: "Tables/deleteTableProcess",
            type: "POST",
            data:{"tableId":id},
            success: function (response)
            {
                console.log(response);
                if (response == 1)
                {   
                    $("#row_"+id).fadeOut('slow');
                    
                }
                else
                {
                    alert("Table not delete");
                    return false;
                } 
            },
            error: function (response) {
               alert("Error occurd! Please try again");
            }
        });    
    else
    return false;        
 }