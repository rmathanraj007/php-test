<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Items extends CI_Controller{
    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('isLogin')){ 
            redirect('Home');    
        } 
        $this->load->database();
        $this->load->model('Item_Model');
        header("Access-Control-Allow-Origin: *");
    }
    
    public function Index(){
        $this->load->view('template/users_head');
        $this->load->view('admin/showitem_view');
        $this->load->view('template/closeTag');
    }
    public function loadItems(){
        $data=$this->Item_Model->getItem();
        echo json_encode($data);
        exit();
        
    }
}
?>